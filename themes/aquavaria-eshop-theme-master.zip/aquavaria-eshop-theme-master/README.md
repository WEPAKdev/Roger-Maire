# PrestaShop Classic Theme

The Classic Theme is the new default Theme for Prestashop 1.7 and onwards.
It is build upon the new Starter Theme.
