'use strict';

import $ from 'jquery';

export default class Brand {
  init() {
    this.initGrid();
    this.initCarousel();
  }

  initGrid() {
    // bind grid toggling (excluding front page)
    $('#grid-toggle').on('click', (event) => {
      if (!$('body').hasClass('nabidka')) {
        this.toggleGrid();

        // bind closing function
        $(document).on('click', (event) => {
          if (!$(event.target).closest('.grid').length) {
            this.toggleGrid();
          }

          $(document).unbind('click');
        });
      }

      return false;
    });

    // to hover item in viewport on mobiles
    if ('ontouchstart' in document.documentElement) {
      $(document).on('load scroll resize', (event) => {
          $('.grid a').each((i, element) => {
              if (inViewport(element)) {
                element.classList.add('hover');
              } else {
                element.classList.remove('hover');
              }
            });
        });
    }
  }

  toggleGrid() {
    $('body').toggleClass('grid-active');
    $('#grid-toggle').parent().toggleClass('active');
    if ('activeElement' in document) document.activeElement.blur();
  }

  initCarousel() {
    setInterval(this.cycleCarousel, 8000);
  }

  cycleCarousel() {
    var active = $('.brand-header .carousel .active').removeClass('active');
    if (active.next() && active.next().length) {
      active.next().addClass('active');
    } else {
      active.siblings(':first').addClass('active');
    }
  }
}
